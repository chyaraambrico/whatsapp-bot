import os
from flask import Flask, request
from twilio.twiml.messaging_response import MessagingResponse
from dotenv import load_dotenv
import openai
import datetime

load_dotenv()
app = Flask(__name__)
openai.api_key = os.getenv("OPENAI_API_KEY")

@app.route("/whatsapp", methods=["POST"])
def whatsapp_reply():
    incoming_msg = request.values.get("Body", "").lower().strip()
    resp = MessagingResponse()
    msg = resp.message()

    if "hilfe" in incoming_msg:
        msg.body("Verfügbare Befehle:
- 'witz'
- 'zeit'
- 'info [frage]'")
    elif "witz" in incoming_msg:
        msg.body("Warum ging der Pilz auf die Party? Weil er ein Champignon war! 🍄😄")
    elif "zeit" in incoming_msg:
        now = datetime.datetime.now().strftime("%d.%m.%Y %H:%M:%S")
        msg.body(f"Aktuelle Zeit: {now}")
    elif "info" in incoming_msg:
        frage = incoming_msg.replace("info", "").strip()
        if frage:
            try:
                antwort = openai.ChatCompletion.create(
                    model="gpt-3.5-turbo",
                    messages=[{"role": "user", "content": frage}]
                ).choices[0].message["content"]
                msg.body(antwort)
            except Exception as e:
                msg.body("Fehler bei der KI-Antwort.")
        else:
            msg.body("Bitte gib eine Frage nach 'info' ein.")
    else:
        msg.body("Ich habe dich nicht verstanden. Schreibe 'hilfe' für Optionen.")

    return str(resp)

if __name__ == "__main__":
    app.run(host="0.0.0.0", port=5000)
